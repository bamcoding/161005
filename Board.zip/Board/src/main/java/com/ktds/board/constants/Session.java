package com.ktds.board.constants;

public interface Session {
	
	public static final String USER_INFO = "_USER_INFO_";
	public static final String SEARCH_INFO = "_SEARCH_INFO_";

}
