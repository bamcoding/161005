package net.gondor.story.dao;

import java.util.List;

import net.gondor.story.vo.StoryVO;

public class application {
	
	public static void main(String[] args) {
		StoryDaoImpl dao = new StoryDaoImpl();
		
	}
}
